// Ares site -> VPS webhook
// IMPORTANT: do NOT hard-code WEBHOOK_SECRET in a public GitHub page.
// Put this call behind your server/proxy or inject a short-lived server-side credential.

async function sendAresSignalToBridge(signal, webhookUrl, webhookSecret) {
  const payload = {
    id: signal.id || ("ARES-" + Date.now()),
    symbol: signal.symbol || "XAUUSD",
    side: signal.dir === "ACHAT" ? "BUY" : "SELL",
    orderType: "LIMIT",
    entry: Number(signal.entry),
    sl: Number(signal.sl),
    tp1: Number(signal.tp1),
    tp2: signal.tp2 == null ? null : Number(signal.tp2),
    tp3: signal.tp3 == null ? null : Number(signal.tp3),
    volume: signal.volume == null ? null : Number(signal.volume),
    riskPercent: signal.riskPercent == null ? null : Number(signal.riskPercent),
    score: signal.score == null ? null : Number(signal.score),
    tf: signal.tf || "M5",
    magic: 260926,
    createdAt: new Date().toISOString()
  };

  const r = await fetch(webhookUrl, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-webhook-secret": webhookSecret
    },
    body: JSON.stringify(payload)
  });

  const data = await r.json();
  if (!r.ok || !data.ok) throw new Error(data.error || "Webhook rejected");
  return data;
}
