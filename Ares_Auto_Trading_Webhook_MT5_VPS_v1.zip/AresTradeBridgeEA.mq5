//+------------------------------------------------------------------+
//| AresTradeBridgeEA.mq5                                           |
//| Receives signals from Ares VPS bridge and executes in MT5.      |
//| DEFAULT: trading disabled until EnableTrading=true.              |
//+------------------------------------------------------------------+
#property strict
#include <Trade/Trade.mqh>

CTrade trade;

input string BridgeURL       = "https://YOUR-DOMAIN.example.com";
input string EAToken         = "CHANGE_ME_EA_TOKEN";
input bool   EnableTrading   = false;
input bool   AllowMarket     = false;
input int    PollSeconds     = 3;
input int    DeviationPoints = 30;
input long   DefaultMagic    = 260926;
input double FixedVolume     = 0.01;

string lastProcessedId = "";
datetime lastPoll = 0;

string JsonString(string json, string key)
{
   string needle = "\"" + key + "\"";
   int p = StringFind(json, needle);
   if(p < 0) return "";
   p = StringFind(json, ":", p);
   if(p < 0) return "";
   p++;
   while(p < StringLen(json) && (StringGetCharacter(json,p)==' ' || StringGetCharacter(json,p)=='\"')) p++;
   int e = p;
   while(e < StringLen(json))
   {
      ushort c = StringGetCharacter(json,e);
      if(c=='\"' || c==',' || c=='}' || c=='\n' || c=='\r') break;
      e++;
   }
   return StringSubstr(json,p,e-p);
}

double JsonNumber(string json, string key, double fallback=0.0)
{
   string v = JsonString(json,key);
   if(v=="") return fallback;
   return StringToDouble(v);
}

bool SendAck(string id, string status, string message)
{
   string url = BridgeURL + "/api/v1/ack";
   string body = "{\"id\":\""+id+"\",\"status\":\""+status+"\",\"message\":\""+message+"\"}";
   char data[], result[];
   StringToCharArray(body,data,0,WHOLE_ARRAY,CP_UTF8);
   string headers = "Content-Type: application/json\r\nx-ea-token: " + EAToken + "\r\n";
   string response_headers;
   ResetLastError();
   int code = WebRequest("POST",url,headers,5000,data,result,response_headers);
   return (code >= 200 && code < 300);
}

bool GetSignal(string &json)
{
   string url = BridgeURL + "/api/v1/signal";
   char data[], result[];
   string headers = "x-ea-token: " + EAToken + "\r\n";
   string response_headers;
   ResetLastError();
   int code = WebRequest("GET",url,headers,5000,data,result,response_headers);
   if(code != 200)
   {
      Print("Bridge HTTP error: ",code," MT5 error: ",GetLastError());
      return false;
   }
   json = CharArrayToString(result,0,-1,CP_UTF8);
   return true;
}

bool AlreadyHasOrder(string signalId)
{
   // We use the signal ID as the EA's local idempotency key.
   // The EA also checks existing positions/orders with the same magic.
   for(int i=PositionsTotal()-1;i>=0;i--)
   {
      ulong ticket=PositionGetTicket(i);
      if(ticket==0) continue;
      if(PositionSelectByTicket(ticket))
      {
         if(PositionGetInteger(POSITION_MAGIC)==DefaultMagic)
            return true;
      }
   }
   for(int i=OrdersTotal()-1;i>=0;i--)
   {
      ulong ticket=OrderGetTicket(i);
      if(ticket==0) continue;
      if(OrderSelect(ticket))
      {
         if(OrderGetInteger(ORDER_MAGIC)==DefaultMagic)
            return true;
      }
   }
   return false;
}

void ExecuteSignal(string json)
{
   string id = JsonString(json,"id");
   if(id=="" || id==lastProcessedId) return;

   string symbol = JsonString(json,"symbol");
   string side = JsonString(json,"side");
   string orderType = JsonString(json,"orderType");
   double entry = JsonNumber(json,"entry");
   double sl = JsonNumber(json,"sl");
   double tp1 = JsonNumber(json,"tp1");
   double volume = JsonNumber(json,"volume",FixedVolume);
   long magic = (long)JsonNumber(json,"magic",(double)DefaultMagic);

   if(symbol=="") symbol=_Symbol;
   if(!SymbolSelect(symbol,true))
   {
      SendAck(id,"REJECTED","Symbol unavailable: "+symbol);
      return;
   }

   if(!EnableTrading)
   {
      Print("Signal received (DRY RUN): ",id," ",side," ",symbol," entry=",entry);
      SendAck(id,"DRY_RUN","EnableTrading=false");
      lastProcessedId=id;
      return;
   }

   if(AlreadyHasOrder(id))
   {
      SendAck(id,"SKIPPED","Existing Ares order/position detected");
      lastProcessedId=id;
      return;
   }

   trade.SetExpertMagicNumber(magic);
   trade.SetDeviationInPoints(DeviationPoints);

   bool ok=false;

   if(orderType=="LIMIT")
   {
      if(side=="BUY")
         ok = trade.BuyLimit(volume,entry,symbol,sl,tp1,ORDER_TIME_GTC,0,"ARES:"+id);
      else if(side=="SELL")
         ok = trade.SellLimit(volume,entry,symbol,sl,tp1,ORDER_TIME_GTC,0,"ARES:"+id);
   }
   else if(orderType=="MARKET" && AllowMarket)
   {
      if(side=="BUY")
         ok = trade.Buy(volume,symbol,0.0,sl,tp1,"ARES:"+id);
      else if(side=="SELL")
         ok = trade.Sell(volume,symbol,0.0,sl,tp1,"ARES:"+id);
   }
   else
   {
      SendAck(id,"REJECTED","Market orders disabled or invalid orderType");
      lastProcessedId=id;
      return;
   }

   if(ok)
   {
      string msg = "order accepted; retcode="+IntegerToString((int)trade.ResultRetcode());
      SendAck(id,"EXECUTED",msg);
      lastProcessedId=id;
   }
   else
   {
      string msg = "trade failed; retcode="+IntegerToString((int)trade.ResultRetcode())+
                   " "+trade.ResultRetcodeDescription();
      SendAck(id,"FAILED",msg);
      lastProcessedId=id;
   }
}

int OnInit()
{
   EventSetTimer(MathMax(1,PollSeconds));
   Print("AresTradeBridgeEA started. EnableTrading=",EnableTrading);
   return(INIT_SUCCEEDED);
}

void OnDeinit(const int reason)
{
   EventKillTimer();
}

void OnTimer()
{
   string json;
   if(!GetSignal(json)) return;
   ExecuteSignal(json);
}
