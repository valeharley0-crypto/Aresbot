ARES AI — AUTOMATIC MT5 BRIDGE v1

Architecture:
GitHub Ares site -> HTTPS Webhook -> VPS Node.js API -> MT5 Expert Advisor -> Broker

FILES
- server.js             VPS webhook/queue/ack API
- package.json          Node.js dependency
- AresTradeBridgeEA.mq5 MT5 Expert Advisor
- site-webhook.js       integration example for your Ares site

1) VPS
Install Node.js 20+.
Run:
  npm install
  export WEBHOOK_SECRET='REPLACE_WITH_LONG_RANDOM_SECRET'
  export EA_TOKEN='REPLACE_WITH_ANOTHER_LONG_RANDOM_TOKEN'
  npm start

Use HTTPS in production (reverse proxy such as Nginx/Caddy).
The EA should use the HTTPS public URL.

2) MT5
Compile AresTradeBridgeEA.mq5 in MetaEditor and attach it to a chart.

In MT5:
Tools -> Options -> Expert Advisors
enable:
  Allow WebRequest for listed URL
add:
  https://YOUR-DOMAIN.example.com

WebRequest must be explicitly allowed in MT5.

EA inputs:
  BridgeURL       = your VPS HTTPS URL
  EAToken         = same value as VPS EA_TOKEN
  EnableTrading   = false for testing, true only after demo testing
  AllowMarket     = false (this version is LIMIT-first)
  FixedVolume     = 0.01

3) SEND A TEST SIGNAL
POST /api/v1/webhook with header:
  x-webhook-secret: YOUR_WEBHOOK_SECRET

JSON:
{
  "id": "ARES-TEST-001",
  "symbol": "XAUUSD",
  "side": "BUY",
  "orderType": "LIMIT",
  "entry": 4000.00,
  "sl": 3990.00,
  "tp1": 4020.00,
  "volume": 0.01,
  "tf": "M5",
  "magic": 260926
}

4) TEST ORDER
Keep EnableTrading=false first.
Confirm /health and /api/v1/signal work.
Then use an MT5 DEMO account.
Only after successful demo tests should EnableTrading=true be considered.

IMPORTANT
- Never put WEBHOOK_SECRET or EA_TOKEN in a public GitHub HTML file.
- The server stores the latest signal in RAM; this starter version is intentionally simple.
- For production, add persistent storage, signal expiry, HMAC signatures, HTTPS, authentication, audit logs, and a kill switch.
- This bridge does not guarantee profitable trades; it only automates execution of the signals it receives.
